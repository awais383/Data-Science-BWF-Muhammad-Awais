import numpy as np

# Define the Softmax function
def softmax(z):
    e_z = np.exp(z - np.max(z, axis=1, keepdims=True))
    return e_z / e_z.sum(axis=1, keepdims=True)

# Define the Cross-Entropy Loss function
def cross_entropy_loss(y_true, y_pred):
    n_samples = y_true.shape[0]
    log_likelihood = -np.log(y_pred[np.arange(n_samples), y_true])
    return np.sum(log_likelihood) / n_samples

# Compute gradients
def compute_gradients(X, y_true, y_pred):
    n_samples = X.shape[0]
    num_classes = y_pred.shape[1]
    
    y_true_one_hot = np.eye(num_classes)[y_true]
    
    grad_w = (1 / n_samples) * X.T @ (y_pred - y_true_one_hot)
    grad_b = (1 / n_samples) * np.sum(y_pred - y_true_one_hot, axis=0)
    
    return grad_w, grad_b

# Training function with early stopping
def train_softmax_regression(X_train, y_train, num_classes, learning_rate=0.01, num_epochs=1000, early_stopping_rounds=10):
    n_samples, n_features = X_train.shape
    
    # Initialize weights and biases
    weights = np.zeros((n_features, num_classes))
    biases = np.zeros(num_classes)
    
    best_loss = float('inf')
    patience_counter = 0
    
    for epoch in range(num_epochs):
        # Forward pass
        logits = X_train @ weights + biases
        y_pred = softmax(logits)
        
        # Compute loss
        loss = cross_entropy_loss(y_train, y_pred)
        
        # Compute gradients
        grad_w, grad_b = compute_gradients(X_train, y_train, y_pred)
        
        # Update weights and biases
        weights -= learning_rate * grad_w
        biases -= learning_rate * grad_b
        
        # Early stopping
        if loss < best_loss:
            best_loss = loss
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= early_stopping_rounds:
                print(f"Early stopping at epoch {epoch + 1}")
                break
        
        if epoch % 100 == 0:
            print(f"Epoch {epoch + 1}, Loss: {loss:.4f}")
    
    return weights, biases

# Predict function
def predict(X, weights, biases):
    logits = X @ weights + biases
    y_pred = softmax(logits)
    return np.argmax(y_pred, axis=1)

# Example Usage
if __name__ == "__main__":
    # Example dataset
    X_train = np.array([[0.1, 0.2], [0.4, 0.5], [0.6, 0.7]])
    y_train = np.array([0, 1, 2])

    num_classes = 3

    # Train the model
    weights, biases = train_softmax_regression(X_train, y_train, num_classes)

    # Make predictions
    predictions = predict(X_train, weights, biases)
    print("Predictions:", predictions)

    # Advanced NumPy Usage
    # Split dataset for demonstration
    X_train_part1, X_train_part2 = np.hsplit(X_train, 2)
    y_train_part1, y_train_part2 = np.hsplit(y_train.reshape(-1, 1), 2)
    
    print("X_train_part1:", X_train_part1)
    print("X_train_part2:", X_train_part2)
    print("y_train_part1:", y_train_part1)
    print("y_train_part2:", y_train_part2)
    
    # Concatenate datasets
    X_concat = np.concatenate((X_train_part1, X_train_part2), axis=1)
    y_concat = np.concatenate((y_train_part1, y_train_part2), axis=0)
    
    print("X_concat:", X_concat)
    print("y_concat:", y_concat)
