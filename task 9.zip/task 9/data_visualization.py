import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the tips dataset
tips = sns.load_dataset('tips')

# Set the aesthetic style of the plots
sns.set_style('whitegrid')

# Create a figure and axis
fig, axes = plt.subplots(2, 2, figsize=(15, 10))

# Scatter plot
sns.scatterplot(x='total_bill', y='tip', data=tips, ax=axes[0, 0])
axes[0, 0].set_title('Total Bill vs Tip')

# Histogram
sns.histplot(tips['total_bill'], kde=True, ax=axes[0, 1])
axes[0, 1].set_title('Distribution of Total Bills')

# Box plot
sns.boxplot(x='day', y='total_bill', data=tips, ax=axes[1, 0])
axes[1, 0].set_title('Total Bill by Day')

# Bar plot
sns.barplot(x='sex', y='tip', data=tips, ax=axes[1, 1])
axes[1, 1].set_title('Average Tip by Gender')

# Adjust the spacing between plots
plt.tight_layout()

# Show the plots
plt.show()
