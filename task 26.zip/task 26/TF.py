import tensorflow as tf
from tensorflow.keras import layers
import numpy as np

class MyModel(tf.keras.Model):
    def __init__(self):
        super(MyModel, self).__init__()
        self.dense1 = layers.Dense(128, activation='relu')
        self.dense2 = layers.Dense(64, activation='relu')
        self.out = layers.Dense(10, activation='softmax')  # Assuming a classification problem with 10 classes

    def call(self, inputs):
        x = self.dense1(inputs)
        x = self.dense2(x)
        return self.out(x)

# Create an instance of the model
model = MyModel()

# Loss function
loss_object = tf.keras.losses.SparseCategoricalCrossentropy()

# Optimizer
optimizer = tf.keras.optimizers.Adam()

# Metrics to monitor loss and accuracy
train_loss = tf.keras.metrics.Mean(name='train_loss')
train_accuracy = tf.keras.metrics.SparseCategoricalAccuracy(name='train_accuracy')

# Custom training step
@tf.function
def train_step(inputs, labels):
    with tf.GradientTape() as tape:
        predictions = model(inputs)
        loss = loss_object(labels, predictions)
    gradients = tape.gradient(loss, model.trainable_variables)
    optimizer.apply_gradients(zip(gradients, model.trainable_variables))

    train_loss(loss)
    train_accuracy(labels, predictions)

# Dummy data for demonstration purposes
x_train = np.random.random((1000, 20)).astype(np.float32)  # 1000 samples, 20 features
y_train = np.random.randint(10, size=(1000,)).astype(np.int32)  # 10 classes

# Training loop
epochs = 5
batch_size = 32

for epoch in range(epochs):
    train_loss.reset_states()
    train_accuracy.reset_states()

    for i in range(0, len(x_train), batch_size):
        x_batch = x_train[i:i+batch_size]
        y_batch = y_train[i:i+batch_size]
        train_step(x_batch, y_batch)

    print(f"Epoch {epoch + 1}, Loss: {train_loss.result()}, Accuracy: {train_accuracy.result() * 100}")
