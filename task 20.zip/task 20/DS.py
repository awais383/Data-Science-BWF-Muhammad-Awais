import boto3
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
import pickle

# Initialize Boto3 S3 client
s3 = boto3.client('s3')

# 1. Upload Dataset to S3
bucket_name = 'your-bucket-name'
file_name = 'your-dataset.csv'
s3.upload_file(file_name, bucket_name, file_name)
print(f'Uploaded {file_name} to S3 bucket {bucket_name}.')

# 2. Load Dataset from S3
obj = s3.get_object(Bucket=bucket_name, Key=file_name)
df = pd.read_csv(obj['Body'])
print('Dataset loaded from S3:')
print(df.head())

# 3. Simple Data Analysis
print('\nDescriptive Statistics:')
print(df.describe())

# Assuming the dataset has a target column named 'target'
X = df.drop(columns=['target'])
y = df['target']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 4. Train a Basic Machine Learning Model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate the model
y_pred = model.predict(X_test)
print('\nClassification Report:')
print(classification_report(y_test, y_pred))

# 5. Save the Model to S3
model_file_name = 'random_forest_model.pkl'
with open(model_file_name, 'wb') as model_file:
    pickle.dump(model, model_file)

s3.upload_file(model_file_name, bucket_name, model_file_name)
print(f'\nModel saved to S3 as {model_file_name}.')

