import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Embedding

# Sample text data
text = "The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog."

# Create a mapping from characters to integers
chars = sorted(list(set(text)))
char_to_int = {c: i for i, c in enumerate(chars)}
int_to_char = {i: c for i, c in enumerate(chars)}

# Prepare the dataset
seq_length = 10
x_data = []
y_data = []

for i in range(0, len(text) - seq_length, 1):
    seq_in = text[i:i + seq_length]
    seq_out = text[i + seq_length]
    x_data.append([char_to_int[char] for char in seq_in])
    y_data.append(char_to_int[seq_out])

# Reshape and normalize the input
X = np.reshape(x_data, (len(x_data), seq_length, 1)) / float(len(chars))
y = tf.keras.utils.to_categorical(y_data)

# Define the model
model = Sequential()
model.add(Embedding(len(chars), 50, input_length=seq_length))
model.add(LSTM(256, return_sequences=True))
model.add(LSTM(256))
model.add(Dense(len(chars), activation='softmax'))

# Compile the model
model.compile(loss='categorical_crossentropy', optimizer='adam')

# Train the model
model.fit(X, y, epochs=50, batch_size=64)

# Function to generate text
def generate_text(seed_text, next_chars=100):
    result = seed_text
    for _ in range(next_chars):
        x_pred = np.array([[char_to_int[char] for char in seed_text[-seq_length:]]])
        x_pred = np.reshape(x_pred, (1, seq_length, 1)) / float(len(chars))
        prediction = model.predict(x_pred, verbose=0)
        index = np.argmax(prediction)
        result += int_to_char[index]
        seed_text += int_to_char[index]
    return result

# Generate and print text
seed = "The quick"
generated = generate_text(seed)
print(generated)
