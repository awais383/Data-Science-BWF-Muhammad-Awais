import pandas as pd

# Create a DataFrame
data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Emily'],
    'Age': [25, 30, 35, 40, 45],
    'City': ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Boston']
}
df = pd.DataFrame(data)
print("Original DataFrame:")
print(df)
print()

# Accessing data
print("Accessing data:")
print("First two rows:")
print(df.head(2))  # Show the first 2 rows
print()

# Adding a new column
df['Gender'] = ['Female', 'Male', 'Male', 'Male', 'Female']
print("DataFrame with new 'Gender' column:")
print(df)
print()

# Filtering data
print("Filtering data where Age > 30:")
filtered_df = df[df['Age'] > 30]
print(filtered_df)
print()

# Basic statistics
print("Basic statistics (mean age):")
mean_age = df['Age'].mean()
print("Mean Age:", mean_age)
