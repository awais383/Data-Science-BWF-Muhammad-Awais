import numpy as np

# Create a 1-dimensional array
arr = np.array([1, 2, 3, 4, 5])
print("Original Array:", arr)

# Access elements using indexing
print("Element at index 2:", arr[2])

# Slicing with stride
print("Every second element:", arr[::2])

# Create a 2-dimensional array
arr2d = np.array([[1, 2, 3], [4, 5, 6]])
print("2D Array:")
print(arr2d)

# Accessing elements in a 2D array
print("Element at position (1, 2):", arr2d[1, 2])

# Perform basic operations
arr3 = np.array([7, 8, 9, 10, 11])
sum_arr = arr + arr3
print("Sum of arrays:", sum_arr)

# Using numpy functions
mean_value = np.mean(arr)
print("Mean of array:", mean_value)
