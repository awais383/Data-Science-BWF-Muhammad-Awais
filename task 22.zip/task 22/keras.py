import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import SGD

# XOR dataset
X = np.array([[0, 0],
              [0, 1],
              [1, 0],
              [1, 1]])

y = np.array([[0],
              [1],
              [1],
              [0]])

# Build the neural network model
model = Sequential()

# Input layer with 2 inputs, hidden layer with 2 neurons
model.add(Dense(2, input_dim=2, activation='sigmoid'))

# Output layer with 1 neuron
model.add(Dense(1, activation='sigmoid'))

# Compile the model
model.compile(loss='mean_squared_error', optimizer=SGD(learning_rate=0.1))

# Train the model
model.fit(X, y, epochs=10000, verbose=0)

# Evaluate the model
predictions = model.predict(X)
print("Predicted Output:\n", predictions)

# Final weights and biases
print("\nFinal Weights and Biases:")
for layer in model.layers:
    weights, biases = layer.get_weights()
    print(f"Weights: {weights}, Biases: {biases}")
