import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load data from a CSV file
df = pd.read_csv('data.csv')

# Display the first few rows of the dataframe
print("First few rows of the dataframe:")
print(df.head())

# Basic data manipulation: calculating the mean of a column
column_mean = df['column_name'].mean()
print(f"\nMean of column 'column_name': {column_mean}")

# Adding a new column with calculated values
df['new_column'] = df['column_name'] * 2

# Display the first few rows of the dataframe with the new column
print("\nDataframe with the new column added:")
print(df.head())

# Plotting a graph
plt.figure(figsize=(10, 6))
plt.plot(df['column_name'], df['new_column'], label='New Column')
plt.xlabel('Original Column')
plt.ylabel('New Column')
plt.title('Original Column vs New Column')
plt.legend()
plt.show()
