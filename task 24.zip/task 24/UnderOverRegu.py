import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split

# Create a synthetic dataset
np.random.seed(42)
X = np.linspace(0, 10, 100)
y = 2 * X**3 - 15 * X**2 + 7 * X + np.random.normal(0, 100, size=X.shape)

# Reshape X to be a 2D array
X = X.reshape(-1, 1)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Function to plot results
def plot_model(X_train, y_train, X_test, y_test, model, title):
    plt.figure(figsize=(10, 6))
    plt.scatter(X_train, y_train, color='blue', label='Training data')
    plt.scatter(X_test, y_test, color='red', label='Test data')
    plt.plot(X, model.predict(X), color='green', label='Model prediction')
    plt.title(title)
    plt.xlabel('X')
    plt.ylabel('y')
    plt.legend()
    plt.show()

# 1. Underfitting: Linear Regression (Low Complexity Model)
linear_model = LinearRegression()
linear_model.fit(X_train, y_train)
print("Linear Regression (Underfitting)")
print("Training MSE:", mean_squared_error(y_train, linear_model.predict(X_train)))
print("Test MSE:", mean_squared_error(y_test, linear_model.predict(X_test)))
plot_model(X_train, y_train, X_test, y_test, linear_model, 'Linear Regression (Underfitting)')

# 2. Overfitting: Polynomial Regression with High Degree (High Complexity Model)
poly_features_high = PolynomialFeatures(degree=15)
X_poly_high_train = poly_features_high.fit_transform(X_train)
X_poly_high_test = poly_features_high.transform(X_test)

poly_model_high = LinearRegression()
poly_model_high.fit(X_poly_high_train, y_train)
print("Polynomial Regression (Overfitting, Degree 15)")
print("Training MSE:", mean_squared_error(y_train, poly_model_high.predict(X_poly_high_train)))
print("Test MSE:", mean_squared_error(y_test, poly_model_high.predict(X_poly_high_test)))
plot_model(X_train, y_train, X_test, y_test, poly_model_high, 'Polynomial Regression (Overfitting, Degree 15)')

# 3. Regularization: Ridge Regression (With Regularization to Prevent Overfitting)
ridge_model = Ridge(alpha=1.0)
ridge_model.fit(X_poly_high_train, y_train)
print("Ridge Regression (Regularization)")
print("Training MSE:", mean_squared_error(y_train, ridge_model.predict(X_poly_high_train)))
print("Test MSE:", mean_squared_error(y_test, ridge_model.predict(X_poly_high_test)))
plot_model(X_train, y_train, X_test, y_test, ridge_model, 'Ridge Regression (Regularization)')
