import nltk
from nltk.stem.snowball import SnowballStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
import streamlit as st

# Ensure punkt tokenizer is available
nltk.download('punkt')

# Load and display the dataset
@st.cache_data
def load_data():
    amzon_df = pd.read_csv('amazon_product.csv')
    amzon_df.drop('id', axis=1, inplace=True)
    return amzon_df

# Function for stemming and tokenizing text
stemmer = SnowballStemmer("english")

def tokenize_stem(text):
    tokens = nltk.word_tokenize(text.lower())
    stem = [stemmer.stem(w) for w in tokens]
    return " ".join(stem)

# Function to calculate cosine similarity
tfidvectorizer = TfidfVectorizer(tokenizer=tokenize_stem)

def cosine_sim(txt1, txt2):
    tfid_matrix = tfidvectorizer.fit_transform([txt1, txt2])
    return cosine_similarity(tfid_matrix)[0][1]

# Function to search and return top 10 product matches
def search_product(query, amzon_df):
    stemmed_query = tokenize_stem(query)
    amzon_df['similarity'] = amzon_df['stemmed_tokens'].apply(lambda x: cosine_sim(stemmed_query, x))
    results = amzon_df.sort_values(by='similarity', ascending=False).head(10)[['Title', 'Description', 'Category']]
    return results

# Load the dataset
amzon_df = load_data()

# Preprocess the data to add stemmed tokens
amzon_df['stemmed_tokens'] = amzon_df.apply(lambda row: tokenize_stem(row['Title'] + ' ' + row['Description']), axis=1)

# Streamlit app UI
st.title("Amazon Product Search")

st.write("This app allows you to search for products based on cosine similarity.")

# Input from user
query = st.text_input("Enter a product query to search for similar items:")

if query:
    st.write(f"Searching for products similar to: **{query}**")
    
    # Search for the product
    results = search_product(query, amzon_df)
    
    # Display results
    st.write("Top 10 results:")
    st.dataframe(results)
