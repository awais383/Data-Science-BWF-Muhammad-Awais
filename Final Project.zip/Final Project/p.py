import nltk
nltk.download('punkt', download_dir='C:\\Users\\MUHAMMAD AWAIS\\AppData\\Roaming\\nltk_data')
